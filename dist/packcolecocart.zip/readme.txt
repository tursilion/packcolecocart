Quick and dirty tool to pack data into a ColecoVision Megacart

packcolecocart <outfile> <program> <data1> <data2> <data3> ...

Program first ensures that the program is padded to 8k (warn if bigger).

For each datafile in the list:
-Report the address and the bank switch for it
-for each 8k page, copy 16384-256 bytes of the data (to avoid Megacart switching area)
-pad the last block of each file to 16k, no sharing
-copy the program into the last page
-after the last file, report the next free page

For now, assumes your program is 16k or less
